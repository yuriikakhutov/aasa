--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
____exports.creep_is_immune = {"modifier_fountain_glyph", "modifier_crystal_maiden_frostbite"}
____exports.enemy_is_immune = {"modifier_necrolyte_reapers_scythe", "modifier_winter_wyvern_winters_curse", "modifier_winter_wyvern_winters_curse_aura", "modifier_troll_warlord_battle_trance"}
____exports.enemy_is_undead = {"modifier_dazzle_shallow_grave", "modifier_oracle_false_promise_timer", "modifier_abaddon_borrowed_time"}
____exports.enemy_not_illusion = {
    "modifier_item_satanic_unholy",
    "modifier_item_mask_of_madness_berserk",
    "modifier_black_king_bar_immune",
    "modifier_rune_doubledamage",
    "modifier_rune_regen",
    "modifier_rune_haste",
    "modifier_rune_arcane",
    "modifier_item_phase_boots_active"
}
____exports.enemy_is_illusion = {
    "modifier_illusion",
    "modifier_phantom_lancer_doppelwalk_illusion",
    "modifier_phantom_lancer_juxtapose_illusion",
    "modifier_darkseer_wallofreplica_illusion",
    "modifier_terrorblade_conjureimage"
}
____exports.hero_is_taunted = {"modifier_axe_berserkers_call", "modifier_legion_commander_duel", "modifier_winter_wyvern_winters_curse", "modifier_winter_wyvern_winters_curse_aura"}
____exports.hero_is_healing = {
    "modifier_flask_healing",
    "modifier_clarity_potion",
    "modifier_item_urn_heal",
    "modifier_item_spirit_vessel_heal",
    "modifier_bottle_regeneration"
}
____exports.hero_not_invisible = {"modifier_item_dustofappearance", "modifier_sniper_assassinate", "modifier_bounty_hunter_track"}
return ____exports
