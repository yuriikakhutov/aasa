--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
____exports.number = "0.7.39 - 2025/09/16"
____exports.recentChangeLogs = {"GLHF"}
return ____exports
