version = '0.7.39'
versionString = [[Changelog: 
  Check out steam Workshop page: https://steamcommunity.com/workshop/filedetails/discussion/3246316298/6197594023017709799/
]]
