// Re-export the Lua module as TypeScript
const CustomizeLua = require("../../../bots/Customize/general");
export = CustomizeLua;
