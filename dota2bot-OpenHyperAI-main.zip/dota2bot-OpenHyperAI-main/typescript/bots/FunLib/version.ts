// Note, only the person responsible for publishing new releases in Valve Workshop should change this version.
// Run `npm run release` once before releasing a new version to get the version auto-updated as well. Timezone is UTC+0 if auto-generated.
export const number = "0.7.39 - 2025/09/16";

export const recentChangeLogs = ["GLHF"];
