### Intro

This is for typescript to lua translation post processing to modify the code and import filepaths for bot game scripting.
